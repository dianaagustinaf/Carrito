﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProyectoGrupo3NT.ViewModels
{
    public class FotoProducto
    {
        public IFormFile Foto { get; set; }

    }
}
